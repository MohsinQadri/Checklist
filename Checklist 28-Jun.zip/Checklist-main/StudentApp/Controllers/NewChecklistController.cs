﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StudentApp.Data;
using StudentApp.Models;
using static StudentApp.Models.NewChecklist;

namespace StudentApp.Controllers
{
    public class NewChecklistController : Controller
    {

     

        //public IActionResult EmployeeDropdown()
        //{
        //    NewChecklist model = new NewChecklist();
        //    return View(model);
        //}
        public IActionResult RoleSelect()
        {
            return View();
        }

        private readonly StudentAppContext _context;

        public NewChecklistController(StudentAppContext context)
        {
            _context = context;
        }

        //public IActionResult Index()
        //{
        //    return View(_context.NewChecklist.ToList());
        //}


        // GET: NewChecklist
        public async Task<IActionResult> Index()
        {
            return _context.NewChecklist != null ?
                        View(await _context.NewChecklist.ToListAsync()) :
                        Problem("Entity set 'StudentAppContext.NewChecklist'  is null.");
        }


        [HttpPost]
        public FileResult Export(string GridHtml)
        {
            return File(Encoding.ASCII.GetBytes(GridHtml), "application/vnd.ms-excel", "Grid.xls");
        }


        // GET: NewChecklist/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.NewChecklist == null)
            {
                return NotFound();
            }

            var newChecklist = await _context.NewChecklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (newChecklist == null)
            {
                return NotFound();
            }

            return View(newChecklist);
        }

        // GET: NewChecklist/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: NewChecklist/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,ReptId,ClientName,ContractingCountry,AuditStartDate,AuditEndDate,LeadAuditor,MajorNC,MinorNC,LeadAuditor1,MajorNC1,MinorNC1")] NewChecklist newChecklist)
        {
            if (ModelState.IsValid)
            {
                _context.Add(newChecklist);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(newChecklist);
        }

        // GET: NewChecklist/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.NewChecklist == null)
            {
                return NotFound();
            }

            var newChecklist = await _context.NewChecklist.FindAsync(id);
            if (newChecklist == null)
            {
                return NotFound();
            }
            return View(newChecklist);
        }

        // POST: NewChecklist/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,ReptId,ClientName,ContractingCountry,AuditStartDate,AuditEndDate,LeadAuditor,MajorNC,MinorNC,LeadAuditor1,MajorNC1,MinorNC1")] NewChecklist newChecklist)
        {
            if (id != newChecklist.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(newChecklist);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!NewChecklistExists(newChecklist.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(newChecklist);
        }

        // GET: NewChecklist/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.NewChecklist == null)
            {
                return NotFound();
            }

            var newChecklist = await _context.NewChecklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (newChecklist == null)
            {
                return NotFound();
            }

            return View(newChecklist);
        }

        // POST: NewChecklist/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.NewChecklist == null)
            {
                return Problem("Entity set 'StudentAppContext.NewChecklist'  is null.");
            }
            var newChecklist = await _context.NewChecklist.FindAsync(id);
            if (newChecklist != null)
            {
                _context.NewChecklist.Remove(newChecklist);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool NewChecklistExists(int id)
        {
          return (_context.NewChecklist?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
