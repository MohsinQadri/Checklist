﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace StudentApp.Migrations
{
    /// <inheritdoc />
    public partial class addingcomment : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Q1Comnt",
                table: "NewChecklist",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Q2Comnt",
                table: "NewChecklist",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Q3Comnt",
                table: "NewChecklist",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Q4Comnt",
                table: "NewChecklist",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Q5Comnt",
                table: "NewChecklist",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Q1Comnt",
                table: "NewChecklist");

            migrationBuilder.DropColumn(
                name: "Q2Comnt",
                table: "NewChecklist");

            migrationBuilder.DropColumn(
                name: "Q3Comnt",
                table: "NewChecklist");

            migrationBuilder.DropColumn(
                name: "Q4Comnt",
                table: "NewChecklist");

            migrationBuilder.DropColumn(
                name: "Q5Comnt",
                table: "NewChecklist");
        }
    }
}
