﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace StudentApp.Migrations
{
    /// <inheritdoc />
    public partial class NewCHecklist : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Checklist",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ReptId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClientName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ContractingCountry = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AuditStartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    AuditEndDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LeadAuditor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MajorNC = table.Column<float>(type: "real", nullable: true),
                    MinorNC = table.Column<float>(type: "real", nullable: true),
                    Q1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Q2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Q3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Q4 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Q5 = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Checklist", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "NewChecklist",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ReptId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClientName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ContractingCountry = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AuditStartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    AuditEndDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LeadAuditor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MajorNC = table.Column<float>(type: "real", nullable: true),
                    MinorNC = table.Column<float>(type: "real", nullable: true),
                    LeadAuditor1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MajorNC1 = table.Column<float>(type: "real", nullable: true),
                    MinorNC1 = table.Column<float>(type: "real", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_NewChecklist", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Checklist");

            migrationBuilder.DropTable(
                name: "NewChecklist");
        }
    }
}
