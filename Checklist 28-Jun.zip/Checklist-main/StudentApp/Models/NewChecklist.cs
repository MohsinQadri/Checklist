﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using static StudentApp.Controllers.NewChecklistController;

namespace StudentApp.Models
{
    
    public class NewChecklist
    {

        //public  NewChecklist()
        //{
        //    ContractingCountry = new List<DropDownList>() {
        //    new DropDownList { Text = "India", Value = 1 },
        //    new DropDownList { Text = "France", Value = 2 },
        //    new DropDownList { Text = "Saudi Arabia", Value = 3 },
        //    new DropDownList { Text = "Italy", Value = 4 },
        //    new DropDownList { Text = "Africa", Value = 5 },
        //};
        //}

        //[Keyless]
        //public class DropDownList
        //{
        //    public string? Text { get; set; }
        //    public int Value { get; set; }

        //}


        public int Id { get; set; }
        public string? ReptId { get; set; }
        public string? ClientName { get; set; }
        public string? ContractingCountry { get; set; }
        public DateTime? AuditStartDate { get; set; }
        public DateTime? AuditEndDate { get; set; }
        public string? LeadAuditor { get; set; }
        public float? MajorNC { get; set; }
        public float? MinorNC { get; set; }
        public string? LeadAuditor1 { get; set; }
        public float? MajorNC1 { get; set; }
        public float? MinorNC1 { get; set; }
        public string? Q1 { get; set;}
        public string? Q2 { get; set;}
        public string? Q3 { get; set;}
        public string? Q4 { get; set;}
        public string? Q5 { get; set;}
        public string? Q1Comnt { get; set; }
        public string? Q2Comnt { get; set; }
        public string? Q3Comnt { get; set; }
        public string? Q4Comnt { get; set; }
        public string? Q5Comnt { get; set; }

    }
}
