﻿namespace StudentApp.Models
{
    public class Checklist 
    {
        public int Id { get; set; }
        public string? ReptId { get; set; }
        public string? ClientName { get; set; }
        public string? ContractingCountry { get; set; }
        public DateTime? AuditStartDate { get; set; }
        public DateTime? AuditEndDate { get; set; }
        public string? LeadAuditor { get; set; }
        public float? MajorNC { get; set; }
        public float? MinorNC { get; set; }
    }
}
