﻿using NuGet.Protocol.Core.Types;

namespace StudentApp.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public String? Address { get; set; }
    }
}
